<?php
// Connection
$servername = "borregobo.com";
$username = "borregob_dm";
$password = "%u_IuSMQUzys";
$dbname = "borregob_dnd";
$conn = new mysqli($servername, $username, $password, $dbname);

class Response {
    // Object properties
	public $tacha;
    public $triangulo;
    public $h;


    // Constructor for object
    public function __construct($tacha, $triangulo, $h) {
    	$this->tacha = $tacha;
    	$this->triangulo = $triangulo;
    	$this->h = $h;
    }
  }

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

# Preparing the statement
$myquery = $conn->prepare('SELECT * FROM field ORDER BY num DESC LIMIT 1');
$myquery->execute();

$results = $myquery->get_result();
$row = $results->fetch_array(MYSQLI_NUM);

$json = new Response($row["1"], $row["2"], $row["3"]);
echo json_encode($json);
?>