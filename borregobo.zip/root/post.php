<?php
// Connection
$servername = "borregobo.com";
$username = "borregob_dm";
$password = "%u_IuSMQUzys";
$dbname = "borregob_dnd";
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$m1 = $_POST['tacha'];
$m2 = $_POST['triangulo'];
$m3  = $_POST['h'];

// Injection protected query
$postResponse = $conn->prepare('INSERT INTO field (tacha, triangulo, h) VALUES (?,?,?);');
$postResponse->bind_param('sss', $m1, $m2, $m3); // 's' specifies the variable type => 'string'

// Execute query
$postResponse->execute();
?>
